# app/__init__.py
from flask import Flask, render_template, request
import paramiko

def create_app():
	app = Flask(__name__)
	#Route de base du site renvoie vers la homepage
	@app.route('/')
	def iot_homepage():
		return render_template('iot_homepage.html', message="")
	#Route de base avec une methode POST renvoie sur la homepage
	@app.route('/', methods=['POST'])
	def iot_homepage_post():
		if request.method == 'POST':
			message=""
			machine = request.form['machine']
			charge = request.form['cpu']
			duree = request.form['time']
			#=========================
			#Traitement des données Singularity
			f = open('./alpineBase.def','r')
			recipe = f.read()
			recipeNew = recipe[0:112]+charge+recipe[113:123]+duree+recipe[124:239]
			f.close() 
			f = open('./alpine.def','w')
			f.write(recipeNew)
			f.close()
			
			login = 'grandmoa'
			psw = 'Grandmougin6'
			commande = 'python3 -m venv env && bash && source env/bin/activate && source env/bin/activate && pip3 install spython && python stress.py'
			
			client = paramiko.SSHClient()
			client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
			client.connect(hostname=machine, username= login, password= psw, timeout=4)
			
			sftp = client.open_sftp()
			sftp.put('./alpine.def','./alpine.def')	
			sftp.put('./stress.py','./stress.py')	

			stdin, stdout, stderr = client.exec_command(commande)
			client.close()
			#===========================
			if(duree!=0):
				message="CPU lancé à "+str(charge)+"% pendant "+str(duree)+" secondes sur la machine "+machine+"."
			else:
				message="Durée nulle, le CPU n'a pas été chargé."

			return render_template('iot_homepage.html', message=message)			
	#Route vers la page iot_containers avec methode GET
	@app.route('/iot_containers/', methods=['GET'])
	def iot_containers():
		if request.method == 'GET':
			res = request.args['machine']
			return render_template('iot_containers.html', machine=res)
		
	return app
